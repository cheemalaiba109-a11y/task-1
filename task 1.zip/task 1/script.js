const gallery = document.getElementById('gallery');
const buttons = document.querySelectorAll('.filters button');

// Predefined 5 images per category
const images = {
  nature: [
    "https://images.unsplash.com/photo-1501785888041-af3ef285b470",
    "https://images.unsplash.com/photo-1441974231531-c6227db76b6e",
    "https://images.unsplash.com/photo-1506748686214-e9df14d4d9d0",
    "https://images.unsplash.com/photo-1470770841072-f978cf4d019e",
    "https://images.unsplash.com/photo-1507525428034-b723cf961d3e"
  ],
  animals: [
    "https://images.unsplash.com/photo-1518717758536-85ae29035b6d",
    "https://images.unsplash.com/photo-1517849845537-4d257902454a",
    "https://images.unsplash.com/photo-1508672019048-805c876b12d2",
    "https://images.unsplash.com/photo-1517423440428-a5a00ad493e8",
    "https://images.unsplash.com/photo-1504208434309-cb69f4fe52b0"
  ],
  cities: [
    "https://images.unsplash.com/photo-1494783367193-149034c05e8f",
    "https://images.unsplash.com/photo-1467269204594-9661b134dd2b",
    "https://images.unsplash.com/photo-1508057198894-247b23fe5ade",
    "https://images.unsplash.com/photo-1505761671935-60b3a7427bad",
    "https://images.unsplash.com/photo-1500534314209-a25ddb2bd429"
  ],
  technology: [
    "https://images.unsplash.com/photo-1518770660439-4636190af475",
    "https://images.unsplash.com/photo-1519389950473-47ba0277781c",
    "https://images.unsplash.com/photo-1517433456452-f9633a875f6f",
    "https://images.unsplash.com/photo-1504384308090-c894fdcc538d",
    "https://images.unsplash.com/photo-1517336714731-489689fd1ca8"
  ]
};

// Function to load images
function loadImages(category) {
  gallery.innerHTML = '';
  let selected = category === 'all' 
    ? [].concat(...Object.values(images)) 
    : images[category];

  selected.forEach(url => {
    const img = document.createElement('img');
    img.src = `${url}?w=400&h=300&fit=crop`;
    gallery.appendChild(img);
  });
}

// Default load
loadImages('all');

// Filter buttons
buttons.forEach(button => {
  button.addEventListener('click', () => {
    const category = button.getAttribute('data-category');
    loadImages(category);
  });
});
